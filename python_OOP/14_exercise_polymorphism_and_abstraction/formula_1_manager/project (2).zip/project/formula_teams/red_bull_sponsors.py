RED_BULL_SPONSORS = {
    "Oracle": {
        1: 1_500_000,
        2: 800_000
    },
    "Honda": {
        8: 20_000,
        10: 10_000
    }
}
