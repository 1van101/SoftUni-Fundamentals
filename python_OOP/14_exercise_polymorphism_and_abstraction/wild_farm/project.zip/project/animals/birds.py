from project.animals.animal import Bird


class Owl(Bird):
    allowed_foods = ['Meat']
    weight_coefficient = 0.25

    def make_sound(self):
        return "Hoot Hoot"


class Hen(Bird):
    allowed_foods = ['Vegetable', 'Fruit', 'Meat', 'Seed']
    weight_coefficient = 0.35

    def make_sound(self):
        return "Cluck"
