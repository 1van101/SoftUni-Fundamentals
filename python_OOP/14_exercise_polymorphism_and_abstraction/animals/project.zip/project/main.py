from cat import Cat
from dog import Dog
from kitten import Kitten
from tomcat import Tomcat

kitten = Kitten("Kiki", 1)
print(kitten.make_sound())
print(kitten)
cat = Cat("Johnny", 7, "Male")
print(cat.make_sound())
print(cat)
