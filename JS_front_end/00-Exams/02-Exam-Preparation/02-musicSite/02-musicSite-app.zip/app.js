window.addEventListener('load', solve);

function solve() {
    let inputs = Array.from(document.querySelectorAll('input'));
    let [genre, name, author, date] = inputs;
    let addBtn = document.getElementById('add-btn');
    let songsCollectionContainer = document.querySelector('.all-hits-container');
    let likesSectionParagraph = document.querySelector('.likes p');
    let savedSongsContainer = document.querySelector('.saved-container');
    addBtn.addEventListener('click', addCollection)
    let newDivCreated = ''
    
    function validInput() {
        inputs.forEach((el) => {
            if (!el.value.trim()) {
                return false
            }
        })
        return true;
    }

    function clearInputFields(){
        inputs.forEach((el) => el.value = '')
    }

    function addCollection(event){
        event.preventDefault()
        console.log(validInput())
        if (validInput()){
            let divHitsInfo = document.createElement('div');
            divHitsInfo.classList = 'hits-info';
            
            let image = document.createElement('img');
            image.src = './static/img/img.png'
            
            let genreH2 = document.createElement('h2');
            genreH2.textContent = genre.value
            
            let nameH2 = document.createElement('h2');
            nameH2.textContent = name.value
            
            let authorH2 = document.createElement('h2');
            authorH2.textContent = author.value
            
            let dateH2 = document.createElement('h2');
            dateH2.textContent = date.value
            
            let saveBtn = document.createElement('button');
            saveBtn.classList = 'save-btn';
            saveBtn.textContent = 'Save song'
            
            let likeBtn = document.createElement('button');
            likeBtn.classList = 'like-btn';
            likeBtn.textContent = 'Like song'
            
            let delBtn = document.createElement('button');
            delBtn.classList = 'delete-btn';
            delBtn.textContent = 'Delete'

            divHitsInfo.append(image, genreH2, nameH2, authorH2, dateH2, saveBtn, likeBtn, delBtn);
            newDivCreated = divHitsInfo
            console.log(newDivCreated)
            songsCollectionContainer.appendChild(divHitsInfo);
            clearInputFields()

            likeBtn.addEventListener('click', ()=>{
                likesSectionParagraph.textContent = 'Total likes: 1'
                likeBtn.disabled = true 
            })

            saveBtn.addEventListener('click', ()=>{
                divHitsInfo.remove()
                saveBtn.remove()
                likeBtn.remove()
                savedSongsContainer.appendChild(newDivCreated)
                delBtn.addEventListener('click', ()=>{
                    divHitsInfo.remove()
                })
            })
        }
    }
}