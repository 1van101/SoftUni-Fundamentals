function attachEvents() {
    let btnLoadPosts = document.getElementById('btnLoadPosts');
    let btnViewPost = document.getElementById('btnViewPost');
    let BASE_URL = 'http://localhost:3030/jsonstore/blog/';
    let posts = document.getElementById('posts');
    let postTitle = document.getElementById('post-title');
    let postBody = document.getElementById('post-body');
    let commentsContainer = document.getElementById('post-comments');

    let postsMapping = {};

    btnLoadPosts.addEventListener('click', loadPosts);
    btnViewPost.addEventListener('click', loadComments);
    async function loadPosts(){
        let response = await fetch(`${BASE_URL}posts`);
        let data = await response.json();
        for (const [key, value] of Object.entries(data)) {
            postsMapping[key] = value.body;
            let newOption = document.createElement('option');
            newOption.value = key;
            newOption.textContent = value.title;
            posts.appendChild(newOption); 
        }
    }

    async function loadComments(){
        let response = await fetch(`${BASE_URL}comments`);
        let data = await response.json();

        let currentPostValue = posts.value
        let currentPostText = posts.options[posts.selectedIndex].text

        commentsContainer.innerHTML = '';
        postTitle.textContent = currentPostText;
        postBody.textContent = postsMapping[currentPostValue]

        for (const [key, value] of Object.entries(data)) {
            if (value.postId === currentPostValue){
                let newLi = document.createElement('li');
                newLi.setAttribute('id', value.id)
                newLi.textContent = value.text
                commentsContainer.appendChild(newLi);
            }
        }
    }
}

attachEvents();